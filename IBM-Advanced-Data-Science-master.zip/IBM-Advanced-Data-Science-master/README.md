<h1 align="center">IBM Advanced Data Science Specialization</h1>
<p align="center">
Notebooks from IBM Advanced Data Science Specialization on Coursera.
</p>

<p align="center">
    <img src="https://github.com/codeamt/IBM-Advanced-Data-Science/blob/master/badge%20final.png" width="30%" height="30%" title="Deep Learning AI Specialization Certificate" >
</p>

## About the Specialization
TODO


<p align="center">
<img src="https://github.com/codeamt/IBM-Advanced-Data-Science/blob/master/cert%20final.jpg" width="70%" height="60%" title="learning scope" >
</p>

## Individual Courses

1. [Fundamentals of Scalable Data Science](https://github.com/codeamt/IBM-Advanced-Data-Science/tree/master/Fundamentals%20of%20Scalable%20Data%20Science)
2. [Advanced Machine Learning and Signal Processing](https://github.com/codeamt/IBM-Advanced-Data-Science/tree/master/Advanced%20Machine%20Learning%20and%20Signal%20Processing)
3. [Applied AI with Deep Learning](https://github.com/codeamt/IBM-Advanced-Data-Science/tree/master/Applied%20AI%20with%20Deep%20Learning)
4. [Advanced Data Science Capstone](https://github.com/codeamt/IBM-Advanced-Data-Science/tree/master/Advanced%20Data%20Science%20Capstone)



